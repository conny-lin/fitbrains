%% INITIALIZING
clc; clear; close all;
%% ADD FUNCTION PATH
addpath('/Users/connylin/Dropbox/Code/Matlab/Library/General');
pFun = { '/Users/connylin/Dropbox/Code/Matlab/Library';
'/Users/connylin/Dropbox/Code/Matlab/Library FB/Modules';
'/Users/connylin/Dropbox/FB/Publication/20160317 Poster SAS Emotion App analysis/Results/Code Library'};
addpath_allsubfolders(pFun);
clear pFun p x;
%% SAVE PATH 
% create save path
timestamp = generatetimestamp;
pSave = mfilename('fullpath');
if isdir(pSave) == 0; mkdir(pSave); end
% make a copy of current code
copyfile([mfilename('fullpath'),'.m'],[pSave,'/',mfilename,'_a',timestamp,'.m']);
%% SETTING
pLegend = '/Users/connylin/Dropbox/Code/Matlab/Library FB/Modules/2-Extraction Cleaning Annotation';
gamelist = 35:38;
%% ----------------------- CODE -------------------------------------------
%% LOAD DATA
% declear legends
% USER INFO
[U,IV,Legends] = load_userinfo_emotion201602('iv',{'user_id','agegroup'});
iv = fieldnames(IV);
% SCORE DATA
Score = load_score_emotion201602('exclude',{'device_id'});
% load preferred DV list
DV = load_legend_score(gamelist);


%% repeat through games
nrow = sum(cellfun(@numel,DV.dv));
for gameid =gamelist
    % get dv
    dv = DV.dv{DV.game_id==gameid};
    % restrict data to current game
    D = get_firstscore(Score(Score.game_id==gameid,:));
    % delete unneeded fields
    D(:,{'id','played_at_utc','game_id'}) = [];
    % match rows: user info with data
    D = outerjoin(D,U,'Keys','user_id','MergeKeys',1);
    D(isnan(D.score) | isnan(D.agegroup),:) = [];
    
    
    %% calculate agegroup mean
    T = table;
    T.agegroup = Legends.agegroup.id;
    for dvi = 1:numel(dv)
        [gn,m] = grpstats((D.(dv{dvi})),D.agegroup,{'gname','mean'});
        a =cellfun(@str2num,gn);
        T.(dv{dvi}) = nan(size(T,1),1);
        [i,j] = ismember(T.agegroup.id,a);
        T.(dv{dvi})(i) = m(j(i));
    end
    
    return
    %% calculate ANOVA
    % package iv 
    IV  =cell(1,numel(iv));
    for ivi = 1:numel(iv)
        IV{ivi} = D.(iv{ivi});
    end
    
    %% loop through dv
    for dvi = 1:numel(dv)
        fprintf('\ncal:%d-%s...',gameIDT,dv{dvi});
        %% full interaction
        [~,t] = anovan(D.(dv{dvi}), IV,'model','full','varnames',iv,'display','off');
        ST = convert_statable(t);
        %% add single factor effect
        for ivi = 1:numel(iv)
            if sum(ST.df(ismember(ST.Source,iv{ivi})))==0
               modelmtrx = zeros(1,3);
               modelmtrx(ismember(iv,iv(ivi))) = 1;
               [~,t] = anovan(D.(dv{dvi}), IV,'model',modelmtrx,'varnames',iv,'display','off');
               t = convert_statable(t);
               ST(ismember(ST.Source,iv{ivi}),2:end) = t(ismember(t.Source,iv{ivi}),2:end);
            end
        end
        
        %% add two factor effect
        for pi = 1:numel(pairname)
            if ST.df(ismember(ST.Source,pairname{pi}))==0
                [~,t] = anovan(D.(dv{dvi}), IV,'model',anovaind(pi,:),'varnames',iv,'display','off');
                t = convert_statable(t);
                ST(ismember(ST.Source,pairname{pi}),2:end) = t(ismember(t.Source,pairname{pi}),2:end);
            end
        end
        
        %% add 3 factor effect
        [~,t] = anovan(D.(dv{dvi}), IV,'model',[1 1 1],'varnames',iv,'display','off');
        t = convert_statable(t);
        ST(ismember(ST.Source,strjoin(iv,'*')),2:end) = t(ismember(t.Source,strjoin(iv,'*')),2:end);
        disp(ST);
        % save
        savename = sprintf('%s/G%d ANOVA AxGxE %s.csv',pSave,gameIDT,dv{dvi});
        writetable(ST,savename);
        close;
        fprintf('\n');
    end
end



%% FINISH
fprintf('\nDONE\n');
return
%     
%         %% summarize yes/no
%         qidu = find(~mcqind);
%         qt = qtext(~mcqind);    
%         % set up empty table
%         a = nan(numel(qidu),8);
%         S = table;
%         S.q = qt;
%         S = [S, array2table(a,'VariableNames',...
%              {'Yes_mean','No_mean','pctd','ES','ANOVA_p','ANOVA_MS','Yes_N','No_N'})];
%         for dvi = 1:numel(dv)
%             S1 = S;
%             for qi = 1:numel(qidu)
%                 x0 = Data.(dv{dvi})(Data.qid==qidu(qi) & Data.ansid==0);
%                 x1 = Data.(dv{dvi})(Data.qid==qidu(qi) & Data.ansid==1);
%                 % anova
%                 [x,group] = transform_cellvar2rowvar([{x0};{x1}]);
%                 group = translate_legend([1 2],{'Yes','No'},group);
%                 [text,T,p,s,t,ST] = anova1_autoresults(x,group);
%                 S1.ANOVA_p(qi) = p;
%                 S1.ANOVA_MS(qi) = ST.F({'Groups'});
%                 % put in table
%                 S1.Yes_mean(qi) = T.mean(ismember(T.gnames,'Yes'));
%                 S1.No_mean(qi) = T.mean(ismember(T.gnames,'No'));
%                 S1.Yes_N(qi) = T.N(ismember(T.gnames,'Yes'));
%                 S1.No_N(qi) = T.N(ismember(T.gnames,'No'));
%                 % effect size and pct diff
%                 S1.ES(qi) = effectsize_cohend(x0,x1);
%                 S1.pctd(qi) = pct_diff(T.mean(ismember(T.gnames,'Yes')),...
%                                 T.mean(ismember(T.gnames,'No')));
%             end
%             writetable(S1,sprintf('%s/G%d %s binary.csv',pSave,gameIDT,dv{dvi}));
%         end
% 
%         %% summarize MC
%         qidu = find(mcqind);
%         qt = qtext(mcqind);    
%         % set up q and answer
%         nrow = sum(sum(~cellfun(@isempty,mcans)));
%         Header = cell(nrow,2);
%         r1 = 1;
%         for qi = 1:numel(qidu)
%             a = mcans(:,qi);
%             a(cellfun(@isempty,a)) = [];
%             n = numel(a);
%             r2 = r1+n-1;
%             Header(r1:r2,1) = repmat(qt(qi),n,1);
%             Header(r1:r2,2) = a;
%             r1 = r2+1;
%         end
%         % set up empty table
%         nrow = size(Header,1);
%         vnames = {'mean','pctd','ES','ANOVA_p','ANOVA_MS','N'};
%         S = table;
%         S.q = Header(:,1);
%         S.ans = Header(:,2);
%         S = [S, array2table(nan(nrow,numel(vnames)),'VariableNames',vnames)];
% 
%         %% calculate
%         for dvi = 1:numel(dv)
%             S1 = S;
%             r1 = 1;
%             for qi = 1:numel(qidu)
%                 x0 = Data.(dv{dvi})(Data.qid==qidu(qi) & Data.ansid==0);
%                 atxt = mcans(:,qi);
%                 atxt(cellfun(@isempty,a)) = [];
%                 S1.mean(r1) = mean(x0);
%                 S1.N(r1) = numel(x0);
%                 S1.pctd(r1) = 0;
%                 S1.ES(r1) = 0;
%                 S1.ANOVA_p(r1) = 0;
%                 S1.ANOVA_MS(r1) = 0;
%                 r1 = r1+1;
%                 aidu = unique(Data.ansid(Data.qid==qidu(qi) & Data.ansid~=0));
%                 for ai = 1:numel(aidu)
%                     x1 = Data.(dv{dvi})(Data.qid==qidu(qi) & Data.ansid==aidu(ai));
%                     % anova
%                     [x,group] = transform_cellvar2rowvar([{x0};{x1}]);
%                     group = translate_legend([1 2],{'Yes','No'},group);
%                     [text,T,p,s,t,ST] = anova1_autoresults(x,group);
%                     S1.ANOVA_p(r1) = p;
%                     S1.ANOVA_MS(r1) = ST.F({'Groups'});
%                     % put in table
%                     S1.mean(r1) = T.mean(ismember(T.gnames,'No'));
%                     S1.N(r1) = T.N(ismember(T.gnames,'No'));
%                     % effect size and pct diff
%                     S1.ES(r1) = effectsize_cohend(x1,x0);
%                     S1.pctd(r1) = pct_diff(T.mean(ismember(T.gnames,'No')),...
%                                     T.mean(ismember(T.gnames,'Yes')));
%                     r1=r1+1;
%                 end
%             end
%             writetable(S1,sprintf('%s/G%d %s MC.csv',pSave,gameIDT,dv{dvi}));
%         end
%     end
% end


















